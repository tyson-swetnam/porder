# -*- coding: utf-8 -*-

__author__ = 'Samapriya Roy'
__email__ = 'samapriya.roy@gmail.com'
__version__ = '0.2.5'
